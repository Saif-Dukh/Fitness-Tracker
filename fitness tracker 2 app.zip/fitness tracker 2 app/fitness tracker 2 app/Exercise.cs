﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace fitness_tracker_2_app
{
    public class Exercise
    {
        public string Naam { get; set; }
        public int Duur { get; set; }
        public int VerbrandeCalorieën { get; set; }

        public override string ToString()
        {
            return Naam;
        }
    }
}
