﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace fitness_tracker_2_app
{
    public partial class MainWindow : Window
    {
        private List<Workout> workouts = new List<Workout>();
        private List<Exercise> availableExercises = new List<Exercise>();
        private string dataFilePath = @"C:\Users\saifu\OneDrive\Bureaublad\fitness_data.json";
        private string exercisesFilePath = @"C:\Users\saifu\OneDrive\Bureaublad\exercises.json";

        public MainWindow()
        {
            InitializeComponent();
            LoadDataFromFile();
            UpdateComboBox();
            UpdateGUI();
        }
        
        private void LoadDataFromFile()
        {
            try
            {
                if (File.Exists(dataFilePath))
                {
                    string jsonData = File.ReadAllText(dataFilePath);
                    dynamic data = JsonConvert.DeserializeObject(jsonData);

                    if (data.workouts != null)
                    {
                        workouts = JsonConvert.DeserializeObject<List<Workout>>(data.workouts.ToString());
                    }
                }

                if (File.Exists(exercisesFilePath))
                {
                    string jsonExercises = File.ReadAllText(exercisesFilePath);
                    dynamic exercisesData = JsonConvert.DeserializeObject(jsonExercises);

                    if (exercisesData.availableExercises != null)
                    {
                        availableExercises = JsonConvert.DeserializeObject<List<Exercise>>(exercisesData.availableExercises.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}");
            }
        }

        private void SaveDataToFile()
        {
            try
            {
                dynamic data = new { workouts, availableExercises };
                string jsonData = JsonConvert.SerializeObject(data);
                File.WriteAllText(dataFilePath, jsonData);

                string exercisesJson = JsonConvert.SerializeObject(availableExercises);
                File.WriteAllText(exercisesFilePath, exercisesJson);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving data: {ex.Message}");
            }
        }

        private void AddExerciseButton_Click(object sender, RoutedEventArgs e)
        {
            if (exerciseComboBox.SelectedItem != null)
            {
                Exercise selectedExercise = (Exercise)exerciseComboBox.SelectedItem;
                workouts.Add(new Workout
                {
                    Datum = DateTime.Today,
                    Type = selectedExercise.Naam,
                    Duur = selectedExercise.Duur,
                    VerbrandeCalorieën = selectedExercise.VerbrandeCalorieën
                });
                UpdateGUI();
            }
        }

        private void AddWorkoutButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateGUI();
        }

        private void RemoveWorkoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (workoutsListView.SelectedItem != null)
            {
                workouts.RemoveAt(workoutsListView.SelectedIndex);
                UpdateGUI();
            }
        }

        private void ShowStatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            int totalBurnedCalories = workouts.Sum(w => w.VerbrandeCalorieën);
            MessageBox.Show($"Total Burned Calories: {totalBurnedCalories}");
        }

        private void UpdateGUI()
        {
            workoutsListView.ItemsSource = null;
            workoutsListView.ItemsSource = workouts;
        }

        private void UpdateComboBox()
        {
            exerciseComboBox.ItemsSource = availableExercises;
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            SaveDataToFile();
            base.OnClosing(e);
        }

        private void exerciseComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (exerciseComboBox.SelectedItem != null)
            {
                Exercise selectedExercise = (Exercise)exerciseComboBox.SelectedItem;
                exerciseDetailsTextBox.Text = $"Duration: {selectedExercise.Duur} minutes\nCalories Burned: {selectedExercise.VerbrandeCalorieën}";
            }
        }
    }
}
