﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fitness_tracker_2_app
{
    public class Workout
    {
        public DateTime Datum { get; set; }
        public string Type { get; set; }
        public int Duur { get; set; }
        public int VerbrandeCalorieën { get; set; }
    }
}
